# Integrated simulation-based optimization approach for production scheduling

Use case implemetation of simulation-based optimization in machining process

## Running

Requeriments:
- R 4.0.4 or superior
- Packages

You can check the package list in 'src/packages.R'. You can install the packages running in the terminal:
  
```sh
Rscript src/packages.R 
```

To run the stable version of the experiment, in the terminal:

```sh
Rscript src/experiment/experiment.R
```

To run the experiment interactively you can use Rstudio or another IDE.

